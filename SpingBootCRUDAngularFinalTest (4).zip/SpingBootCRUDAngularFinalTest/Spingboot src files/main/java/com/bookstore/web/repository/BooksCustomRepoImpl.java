package com.bookstore.web.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;

import com.bookstore.web.model.Books;

public class BooksCustomRepoImpl implements BooksCustomRepo{
	
	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<Books> findByTitle (String title){
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery();
		
		Root<Books> book = cq.from(Books.class);
		
		Predicate titlePredicate = cb.equal(book.get("title"), title);
		
		cq.where(titlePredicate);
		
		TypedQuery<Books> query = entityManager.createQuery(cq);
		return query.getResultList();
	}

}
