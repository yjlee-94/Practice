package com.bookstore.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookWebStoreCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookWebStoreCrudApplication.class, args);
		System.out.println("Springboot rest hiberation connection established");
	}

}
