package com.bookstore.web.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;

import com.bookstore.web.exception.ResourceNotFoundException;
import com.bookstore.web.model.Books;
import com.bookstore.web.repository.BooksRepo;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/bws")
public class BooksController {
	
	@Autowired
	public BooksRepo bkRepo;
	
	// Create a new book rest api
	@PostMapping("/books")
	public Books createBook (@RequestBody Books bk)
	{
		return bkRepo.save(bk);
	}
	
	
	// Find book by title rest api
	@GetMapping("/books/{title}")
	public List<Books> findByTitle (@PathVariable String title)
	{
		return bkRepo.findByTitle(title);
	}
	
	
	// GET ALL BOOKS rest api
	@GetMapping("/books")
	public List<Books> getAllBooks(){
		return bkRepo.findAll();
	}
	
	
	// DELETE book by id
	@DeleteMapping("/books/{isbn}")
	public ResponseEntity<Map<String,Boolean>> deleteBookByID(@PathVariable int isbn){
	{
		Books book = bkRepo.findById(isbn).orElseThrow(()-> new ResourceNotFoundException("Book with id doesn't exist"+ isbn));
		
		bkRepo.delete(book);
		Map<String,Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);}
	}
	
	// Update Book by id rest api
	@PutMapping("/books/{isbn}")
	public ResponseEntity<Books> updateBook(@PathVariable int isbn,@RequestBody Books book){
	{
		Books bk = bkRepo.findById(isbn).orElseThrow(()-> new ResourceNotFoundException("Book with id doesn't exist"+ isbn));
		
		bk.setIsbn(book.getIsbn());
		bk.setAuthors(book.getAuthors());
		bk.setTitle(book.getTitle());
		bk.setPrice(book.getPrice());
		bk.setYear(book.getYear());
		
		Books updatedBk = bkRepo.save(bk);
		return ResponseEntity.ok(updatedBk);
	}
	
	
	

}
}
