package com.bookstore.web.repository;

import java.util.List;

import com.bookstore.web.model.Books;

public interface BooksCustomRepo {

	List<Books> findByTitle(String title);
}
