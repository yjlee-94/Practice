package com.bookstore.web.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Book")
public class Books {
	
	@Id
	@Column(name="isbn", unique= true,nullable=false, length = 8)
	private int isbn;
	
	@Column(name="title",length = 100 ,nullable=false)
	private String title;

//	@ElementCollection 
	@Column(name="authors",length = 30 ,nullable=false)
	private String authors;
	
	@Column(name="year",length=4 ,nullable=false)
	private int year;
	
	@Column(name="price",length=4 ,nullable=false) 
	private int price;

	public Books() {}
	
	public Books(String title,String authors, int yr, int price)
	{
		this.title = title;
		this.authors = authors;
		this.year = yr;
		this.price = price;
	}
	public int getIsbn() {
		return isbn;
	}

	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthors() {
		return authors;
	}

	public void setAuthors(String authors) {
		this.authors = authors;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
}
