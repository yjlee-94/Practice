package com.bookstore.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bookstore.web.model.Books;

@Repository
public interface BooksRepo extends JpaRepository<Books,Integer>,BooksCustomRepo {

}
