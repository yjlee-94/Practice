package com.bookstore.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookWebStoreCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
