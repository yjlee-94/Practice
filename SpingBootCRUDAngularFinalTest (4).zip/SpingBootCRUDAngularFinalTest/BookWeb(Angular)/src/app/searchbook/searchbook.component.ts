import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { Books } from '../books';



@Component({
  selector: 'app-searchbook',
  templateUrl: './searchbook.component.html',
  styleUrls: ['./searchbook.component.css']
})
export class SearchbookComponent implements OnInit {

  titleSearch!:string;
  books!:Books[];
  find:boolean = false;
  bookfound!:Books;
  constructor(private router:Router, private booksvc:BookService) { }

  ngOnInit(): void {
    this.getBooks();
  }



  private getBooks(){
    this.booksvc.getBooksList().subscribe(data=>{
      this.books = data;
    });
  }

  goToHome(){
    this.router.navigate(['/home']);
  }

  onSearch(){
    this.books.forEach(  (element) =>{
      if(element.title ==  this.titleSearch)
      {
        this.bookfound = element;
      }
    });

    if (this.bookfound)
    {
      this.find=true;
    }
    else
    {
      this.find= false;
    }
    // console.log(this.titleSearch);
    // console.log(this.bookfound);
  }
}
