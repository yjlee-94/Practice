import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Books } from './books';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private baseUrl = "http://localhost:7055/bws/books";

  constructor(private httpClient: HttpClient) { }

  // Method that gets all books into a list from the URL link 
  getBooksList():Observable<Books[]>{
    return this.httpClient.get<Books[]>(`${this.baseUrl}`);
  }

   /* Method that post the object over on the same link and then it is in turn received by  
    the springboot application then processed into MySQL database */
    createbook(book:Books):Observable<Object>{
      return this.httpClient.post(`${this.baseUrl}`, book);
   }

   
}
