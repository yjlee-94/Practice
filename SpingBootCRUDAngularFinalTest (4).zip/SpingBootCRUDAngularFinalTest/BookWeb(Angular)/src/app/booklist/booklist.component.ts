import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { Books } from '../books';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  book!:Books[];
  constructor(private router:Router,private bksvc:BookService) { }

  ngOnInit(): void {
    this.getBooks();
  }

  private getBooks(){
    this.bksvc.getBooksList().subscribe(data=>{
      this.book = data;
    });
  }

  goToHome(){
    this.router.navigate(['/home']);
  }
}
