export class Books {
    isbn!:number;
    title!:string;
    authors!:string[];
    year!:number;
    price!:number;
    
}
