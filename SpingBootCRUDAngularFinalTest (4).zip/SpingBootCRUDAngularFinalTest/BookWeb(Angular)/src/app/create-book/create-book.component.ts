import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { Books } from '../books';



@Component({
  selector: 'app-create-book',
  templateUrl: './create-book.component.html',
  styleUrls: ['./create-book.component.css']
})
export class CreateBookComponent implements OnInit {

  books:Books = new Books(); 
  constructor(private router:Router, private booksvc:BookService) { }

  ngOnInit(): void {
  }

  saveBook(){
    this.booksvc.createbook(this.books).subscribe(data=>{
      console.log(data);
      this.gotoCreateBook();
    },
    error => console.log(error));
  }

  gotoCreateBook(){
    this.router.navigate(['/home']);
  }

  onSubmit(){
    console.log(this.books);
    this.saveBook();
  }
}
